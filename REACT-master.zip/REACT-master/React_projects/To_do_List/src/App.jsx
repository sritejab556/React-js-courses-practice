import { BrowserRouter as Router, Routes, Route } from "react-router";
import { useState } from "react";
import './App.css'

import AddTask from "./components/Navbar-items/AddTask";
import Completed from "./components/Navbar-items/Completed";
import UpComing from "./components/Navbar-items/Upcoming";
import Today from "./components/Navbar-items/Today";
import Inbox from "./components/Navbar-items/Inbox";
import Settings from "./components/Navbar-items/Settings";
import ViewProfile from "./components/Navbar-items/ViewProfile";
import Navbar from "./components/Navbar";
import PageNotFound from "./components/PageNotFound";

function App() {
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [showAddTask, setShowAddTask] = useState(false);

  const handleAddTask = (title, description) => {
    console.log("New task added:", title, description);
    setShowAddTask(false);
  };

  const handleCancelTask = () => {
    setShowAddTask(false);
  };

  return (
    <Router>
      <Navbar 
        isOpen={isSidebarOpen}
        setIsOpen={setIsSidebarOpen}
        onOpenAddTask={() => setShowAddTask(true)}
      />

      <div className={`transition-all duration-300 ${isSidebarOpen ? "ml-48" : "ml-0"} p-6`}>
        <Routes>
          <Route path="/view-profile" element={<ViewProfile />} />
          <Route path="/completed" element={<Completed />} />
          <Route path="/upcoming" element={<UpComing />} />
          <Route path="/today" element={<Today />} />
          <Route path="/" element={<Inbox />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/*" element={<PageNotFound />} />
        </Routes>
      </div>

      {showAddTask && (
        <AddTask 
          onAdd={handleAddTask}
          onCancel={handleCancelTask}
          projects={[
            { name: "Work" },
            { name: "Personal" },
            { name: "Shopping" }
          ]}
        />
      )}
    </Router>
  )
}

export default App;
