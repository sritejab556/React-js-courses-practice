export default function PageNotFound(){
    return(
        <div>
            <h1>Page not Found</h1>
        </div>
    )
}