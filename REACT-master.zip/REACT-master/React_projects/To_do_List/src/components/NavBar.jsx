import { NavLink, Link } from "react-router";
import { useState, useRef } from "react";
import useOutsideClick from "../hooks/useOutsideClick";

export default function Navbar({ isOpen, setIsOpen, onOpenAddTask }) {
  const [showProfileMenu, setShowProfileMenu] = useState(false);
  const dropdownRef = useRef(null);

  useOutsideClick(dropdownRef, () => setShowProfileMenu(false));

  return (
    <>
      {isOpen && (
        <div className="fixed top-0 left-0 w-48 h-screen bg-white shadow-lg flex flex-col p-4 space-y-4 z-50">
          {/* Profile dropdown */}
          <div className="flex items-center justify-between mb-6">
            <div className="relative" ref={dropdownRef}>
              <button
                onClick={() => setShowProfileMenu((prev) => !prev)}
                className="text-gray-700 hover:text-blue-500 font-semibold"
              >
                Profile ▼
              </button>
              {showProfileMenu && (
                <div className="absolute mt-2 w-36 bg-white border rounded shadow-md z-50">
                  <Link
                    className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                    to="/view-profile"
                  >
                    View Profile
                  </Link>
                  <Link
                    className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                    to="/settings"
                  >
                    Settings
                  </Link>
                  <Link
                    className="block w-full text-left px-4 py-2 text-gray-700 hover:bg-gray-100"
                    to="/logout"
                  >
                    Logout
                  </Link>
                </div>
              )}
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="text-red-500 text-lg font-bold hover:text-red-700"
            >
              ✕
            </button>
          </div>

          {/* Add Task */}
          <button
            onClick={onOpenAddTask}
            className="px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600 transition"
          >
            + Add Task
          </button>

          {/* Nav Links */}
          <NavLink
            to="/"
            className={({ isActive }) =>
              `text-gray-700 hover:text-blue-500 ${isActive ? "font-bold text-blue-600" : ""}`
            }
          >
            Inbox
          </NavLink>
          <NavLink
            to="/today"
            className={({ isActive }) =>
              `text-gray-700 hover:text-blue-500 ${isActive ? "font-bold text-blue-600" : ""}`
            }
          >
            Today
          </NavLink>
          <NavLink
            to="/upcoming"
            className={({ isActive }) =>
              `text-gray-700 hover:text-blue-500 ${isActive ? "font-bold text-blue-600" : ""}`
            }
          >
            Upcoming
          </NavLink>
          <NavLink
            to="/completed"
            className={({ isActive }) =>
              `text-gray-700 hover:text-blue-500 ${isActive ? "font-bold text-blue-600" : ""}`
            }
          >
            Completed
          </NavLink>
        </div>
      )}

      {/* Open Sidebar */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed top-4 left-4 z-50 p-2 bg-blue-500 text-white rounded shadow-lg hover:bg-blue-600"
        >
          ☰
        </button>
      )}
    </>
  );
}
