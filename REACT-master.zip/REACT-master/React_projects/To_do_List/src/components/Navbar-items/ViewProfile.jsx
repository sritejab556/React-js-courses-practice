export default function ViewProfile(){
    return(
        <div>
            
            <h1>Profile Section</h1>
        </div>
    )
}