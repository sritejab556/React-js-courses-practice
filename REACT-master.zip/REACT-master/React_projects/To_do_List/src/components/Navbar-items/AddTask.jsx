import { useState, useRef } from "react";
import useOutsideClick from "../../hooks/useOutsideClick";

export default function AddTask({ onAdd, onCancel }) {
    const modalRef = useRef(null);
    useOutsideClick(modalRef, onCancel);

    const [newTask,setnewTask]=useState([]); 
    
    const [taskText, setTaskText] = useState("");
    const [description, setDescription] = useState("");
    const projects = [
        { name: "Work" },
        { name: "Personal" },
        { name: "Shopping" },
    ];


    const handleAdd = () => {
        if (taskText.trim()) {
            onAdd(taskText.trim(), description.trim());
            setTaskText("");
            setDescription("");
        }
    };
    
    return (
        <div ref={modalRef} className="absolute top-24 left-1/2 transform -translate-x-1/2 z-50 max-w-xl w-[min(90vw,600px)] bg-white rounded-xl p-6 shadow-xl">
            <textarea
                className="w-full resize-none text-lg font-bold placeholder-gray-400 border-0 outline-none mb-2"
                placeholder="Add new task title..."
                rows={2}
                value={taskText}
                onChange={(e) => setTaskText(e.target.value)}
                autoFocus
                aria-label="New task title"
            />
            <textarea
                className="w-full resize-none text-sm placeholder-gray-400 border-0 outline-none mb-4 text-gray-500"
                placeholder="Description"
                rows={2}
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                aria-label="New task description"
            />
            <div className="mb-4 flex flex-wrap gap-2">
                {/* Dummy buttons for Date, Priority, Reminders */}
                <button
                    type="button"
                    className="bg-gray-100 text-gray-700 rounded-md px-3 py-1 text-xs font-semibold hover:bg-indigo-50"
                >
                    <span className="material-icons align-middle mr-1 text-sm">calendar_today</span>Date
                </button>
                <button
                    type="button"
                    className="bg-gray-100 text-gray-700 rounded-md px-3 py-1 text-xs font-semibold hover:bg-indigo-50"
                >
                    <span className="material-icons align-middle mr-1 text-sm">flag</span>Priority
                </button>
                <button
                    type="button"
                    className="bg-gray-100 text-gray-700 rounded-md px-3 py-1 text-xs font-semibold hover:bg-indigo-50"
                >
                    <span className="material-icons align-middle mr-1 text-sm">notifications</span>Reminders
                </button>
                <button
                    type="button"
                    className="bg-gray-100 text-gray-700 rounded-md px-3 py-1 text-xs font-semibold hover:bg-indigo-50"
                    aria-label="More options"
                >
                    <span className="material-icons align-middle text-sm">more_horiz</span>
                </button>
            </div>

            <div className="flex justify-between items-center">
                <div className="flex items-center gap-2 text-gray-600">
                    <span className="material-icons text-base">inbox</span>
                    <select
                        aria-label="Select project"
                        className="bg-transparent outline-none text-sm cursor-pointer"
                        defaultValue="Inbox"
                    >
                        <option>Inbox</option>
                        {projects.map((p) => (
                            <option key={p.name}>{p.name}</option>
                        ))}
                    </select>
                </div>

                <div className="flex gap-3">
                    <button
                        onClick={onCancel}
                        type="button"
                        className="px-4 py-2 text-gray-700 border border-gray-300 rounded-md hover:bg-gray-100"
                    >
                        Cancel
                    </button>
                    <button
                        onClick={handleAdd}
                        type="button"
                        className="px-5 py-2 rounded-md bg-rose-300 text-white font-semibold hover:bg-rose-400 transition"
                    >
                        Add task
                    </button>
                </div>
            </div>
        </div>
    );
}