export default function SetDateTime(){
    return(
        <div>
            <h1>Set Date and Time</h1>
        </div>
    )
}