export default function Inbox() {

  return (
    <div className="p-6 ml-52"> {/* ml-52 pushes content right of sidebar */}
      <h1 className="text-2xl font-bold mb-4">Inbox</h1>
    </div>
  );
}
