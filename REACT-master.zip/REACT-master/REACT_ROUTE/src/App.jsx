import { Route, Routes, Link, Navigate } from "react-router"
import NavBar from "./Components/NavBar"
import Home from "./Components/Home";
import About from "./Components/About";
import Login from "./Components/Login";
import PageNotFound from "./Components/PageNotFound";
import Signup from "./Components/Signup";
import College from "./Components/NestedComp/College";
import Users from "./Components/NestedComp/Users";
import UserDetails from "./Components/NestedComp/UserDetails";


function App() {
  return (
    <>


      <Routes>
        <Route element={<NavBar />}>
          <Route path="/" element={<Home />}>
            <Route path="/college" element={<College />} >
            </Route>
            <Route path="/college/user/:id/:name?" element={<UserDetails />} />
            <Route path="/college/user" element={<Users />} />
          </Route>
          <Route path="/about" element={<About />} />

          <Route path="/user">
            <Route path="/user/login" element={<Login />} />
            <Route path="/user/signup" element={<Signup />} />
          </Route>

          <Route path="/*" element={<PageNotFound />} />
          {/* Or Redirect to home page */}
          {/* <Route path="/*" element={<Navigate to="/login" />} /> */}
        </Route >

      </Routes>
    </>
  )
}

export default App
