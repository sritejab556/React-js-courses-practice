export default function PageNotFound(){
    return(
        <div>
        <h1>Page not found</h1>
        <h1>404 Error</h1>
        </div>
    )
}