export default function Login(){
    return(
        <div>
            <h1>Login Part</h1>
        </div>
    )
}