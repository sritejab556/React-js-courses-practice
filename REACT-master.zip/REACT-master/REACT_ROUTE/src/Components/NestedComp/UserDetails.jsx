import { Outlet, useParams,Link } from "react-router";

export default function UserDetails(){
    const paramsData=useParams();
    console.log(paramsData);
    
    return(
        <div>
            <div>
                <Link to={"/college/user"}> Back</Link>
                <h2>User Id is {paramsData.id}</h2>
            </div>
            <Outlet />
        </div>
    )
}

