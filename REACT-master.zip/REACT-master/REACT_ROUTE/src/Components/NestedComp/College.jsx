import { Link, Outlet } from "react-router"
export default function College() {
    return (
        <div>

            <div>
                <Link to={"/"}>Back</Link>
                <h1>MVGR College</h1>
                <h1><Link to="/college/user">Users</Link></h1>
            </div>
            <Outlet />
        </div>
    )
}
