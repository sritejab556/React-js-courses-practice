import { Outlet,Link } from "react-router"

export default function Users() {

    const users = [
        { id: 1, name: "teja" },
        { id: 2, name: "mohan" },
        { id: 3, name: "prudvi" },
        { id: 4, name: "manoj" },
    ]

    return (
        <div>
            <div>

            <Link to={"/college"}>Back</Link>
            <h1>Users in college</h1>
            {
                users.map((item) =>(
                    <div key={item.id}> 
                        <h2><Link to={"/college/user/"+item.id+"/"+item.name}>{item.name}</Link></h2>
                    </div>
                ))
            }
            </div>
            <Outlet />
        </div>
    )
}
