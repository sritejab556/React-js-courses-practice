import { Link ,Outlet} from "react-router"
import "../Css/Home.css"
export default function Home(){
    return(
        <div>
            <h1 class="text-3xl font-bold underline">Home page</h1>
            <div className="sub-head">
                <Link to="college" className="link">College</Link>
            </div>
            <Outlet/>
        </div>
    )
}
