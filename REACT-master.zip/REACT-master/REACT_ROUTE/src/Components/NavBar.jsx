import { NavLink, Outlet } from "react-router";
import "../Css/NavBar.css"
export default function NavBar(){
    return(
        <div>

        <div className="header">
            <div>
                <NavLink className="nav-options" to="/" ><h2>Logo</h2></NavLink>
                
            </div>
            <div >
                <ul>
                    <li><NavLink className="nav-options" to="/" >Home</NavLink></li>
                    <li><NavLink className="nav-options" to="/about">About</NavLink></li>
                    <li><NavLink className="nav-options" to="/user/login">Login</NavLink></li>
                    <li><NavLink className="nav-options" to="/user/signup">Signup</NavLink></li>
                </ul>
            </div>
        </div>
            <Outlet />
        </div>
    )
}