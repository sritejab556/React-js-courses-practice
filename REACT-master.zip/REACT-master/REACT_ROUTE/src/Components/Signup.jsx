export default function Signup(){
    return(
        <div>
            <h1>Sign page</h1>
        </div>
    )
}