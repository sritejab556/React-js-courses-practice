import { useState } from "react";

// import "./App.css";
import Usergreet from "./Components/User.jsx";
import Usergreet2 from "./Components/User.jsx";
import Dog from "./Components/Dog.jsx";
import Toggle from "./Components/Toggle.jsx";
import UserHide from "./Components/UserHide.jsx";
import Multiple_condition from "./Components/Multi.jsx";
import Details from "./Components/props.jsx";
import Details2 from "./Components/props2.jsx";
import Child from "./Components/Child.jsx";
import Wrap from "./Components/Wrap.prop.jsx";
import StuForm from "./Components/Input.Field.jsx";
import CheckBox from "./Components/CheckBox.jsx";
import Radio_Btn from "./Components/Radio.jsx";
import Dropdown from "./Components/Dropdown.jsx";
import DisplayUserData from "./Components/Loops.jsx";
import UserData from "./Components/UserData.jsx";
import DisplayClock from "./Components/Clock.jsx";
import ColorSelect from "./Components/Color.jsx";
import CollegeData from "./Components/College.Data.jsx";
import UseEffect from "./Components/UseEffect.jsx";
import Props from "./Components/UseEffects.props.jsx";
import CheckStyle from "./Components/CssModule.jsx";
import StyledCss from "./Components/StyledCss.jsx";
import Boot from "./Components/BootStrap.jsx";
import UseRef from "./Components/UseRef.jsx";
import Uncontrolled from "./Components/Uncotrolled.jsx";
import Fun1 from "./Components/Fun1.jsx";
import UserForm from "./Components/UseFormStatus.jsx"


function Say() {
  return alert("hi");
}
function App() {
  const [count, setCount] = useState(0);
  let StuDetails={
  nam:"teja",
  age:119,
  study:"Btech"
  }
  let StuDetails2={
  nam:"Jaffa",
  age:118,
  study:"Mtech"
  }
  let arr=[1,2,3,4];

  const [val,setIncrement]=useState(0);


  // for <Props />
  const [count1,setCount1]=useState(0);
  const [count2,setCount2]=useState(0);

  return (
    <div>
      <Usergreet />
      <h2>Love you {count}</h2>
      <button onClick={() => setCount(count + 1 * 1000)}>Love</button>
      <button onClick={() => setCount(count - 1 * 1000)}>Hate</button>
      <button onClick={Say}>Hey</button>
      <Dog />
      <Toggle/>
      <hr/>
      <UserHide/>
      <hr />
      <Multiple_condition/>
      <hr />
      <Details data={StuDetails}/>
      <hr />
      <Details data={StuDetails2}/>
      <hr />
      {/* <Details2 Name="manohar" age={14}/> */}
      <Details2 data={arr}/>
      <hr />
      <Details2/>
      <hr />
      {/* using state updater function (like setState) as a prop to a child component */}
      
      <h2>val : {val}</h2>
      <Child func={setIncrement}/>
      <hr />
      <Wrap color="yellow">
        <h2>this text is inside wrap</h2>
      </Wrap>
      <hr />
      <h1>Controlled component</h1>
      <StuForm/>
      <hr />
      <h1>Handle Checkbox</h1>
      <CheckBox />
      <hr />
      <h1>Handle Radio Buttons</h1>
      <Radio_Btn />
      <hr />
      <h1>Handling Checkbox</h1>
      <Dropdown />
      <hr />
      <h1>Handling Loops</h1>
      <DisplayUserData />
      <hr />
      <h1>Reuse Component in loop</h1>
      <UserData />
      <hr />
      <DisplayClock />
      <hr />
      <ColorSelect />
      <hr />
      <CollegeData />
      <hr />
      <UseEffect />
      <hr />
      <Props count1={count1} count2={count2} />
      <button onClick={()=>{setCount1(count1+1)}}>count1</button>
      <button onClick={()=>{setCount2(count2+1)}}>count2</button>
      <hr />
      <CheckStyle />
      <hr />
      <br />
      <StyledCss />

      <hr />
      <Boot />
      <hr />
      <UseRef />
      <hr />
      <Uncontrolled/>
      <hr /><br />
      <Fun1 />
      <hr />
      <br />
      <UserForm />
      <br /><hr />
      
      
    </div>


  );
}

export default App;
