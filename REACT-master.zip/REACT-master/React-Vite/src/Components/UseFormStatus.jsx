import { useFormStatus } from "react-dom";

function UserForm() {


    const HandleSubmit = async () => {
        await new Promise(res => setTimeout(res, 2000));
        console.log("submit");

    }
    function InputForm() {
        const { pending } = useFormStatus();
        console.log(pending);
        return (
            <div>
                <input type="text" placeholder="Enter name" />
                <button disabled={pending}>{pending ? "submitting.." : "submit"}</button>
            </div>
        )

    }

    return (
        <div>
            <form action={HandleSubmit}>
                <InputForm />
            </form>
        </div>
    )
}

export default UserForm;