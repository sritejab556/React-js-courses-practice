import CollegeTemplate from "./College";

function CollegeData() {
    let data = [
        {
            name: "MVGR",
            website: "www.mvgrce.com",
            type: "autonomous",
            student: [
                {
                    name: "teja",
                    dept: "IT",
                    cgpa: 4.3,
                    id: "22331A1243"
                },
                {
                    name: "vamsi",
                    dept: "IT",
                    cgpa: 7.3,
                    id: "22331A1244"
                },
                {
                    name: "vignesh",
                    dept: "IT",
                    cgpa: 8.3,
                    id: "22331A1245"
                },
                {
                    name: "janaki",
                    dept: "IT",
                    cgpa: 9.3,
                    id: "22331A1241"
                },
            ]
        },
        {
            name: "RAGHU",
            website: "www.raghu.com",
            type: "autonomous",
            student: [
                {
                    name: "teja",
                    dept: "IT",
                    cgpa: 4.3,
                    id: "22331A1243"
                },
                {
                    name: "vamsi",
                    dept: "IT",
                    cgpa: 7.3,
                    id: "22331A1244"
                },
                {
                    name: "vignesh",
                    dept: "IT",
                    cgpa: 8.3,
                    id: "22331A1245"
                },
                {
                    name: "janaki",
                    dept: "IT",
                    cgpa: 9.3,
                    id: "22331A1241"
                },
            ]
        },
        {
            name: "JNTUV",
            website: "www.jntuv.com",
            type: "university",
            student: [
                {
                    name: "teja",
                    dept: "IT",
                    cgpa: 4.3,
                    id: "22331A1243"
                },
                {
                    name: "vamsi",
                    dept: "IT",
                    cgpa: 7.3,
                    id: "22331A1244"
                },
                {
                    name: "vignesh",
                    dept: "IT",
                    cgpa: 8.3,
                    id: "22331A1245"
                },
                {
                    name: "janaki",
                    dept: "IT",
                    cgpa: 9.3,
                    id: "22331A1241"
                },
            ]
        },
    ];

    return (
        <div>
            {data.map((college, index) => (
                <div key={index}>
                    <CollegeTemplate college={college} />
                </div>
                
            ))}
        </div>
    );
}

export default CollegeData;
