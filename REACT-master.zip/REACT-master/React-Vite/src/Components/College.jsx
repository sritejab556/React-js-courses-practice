import UserTemplate from "./UserTemplate";

function CollegeTemplate({college}){
  const containerStyle = {
    border: "1px solid black",
    padding: "16px",
    borderRadius: "8px",
    maxWidth: "500px",
    margin: "16px auto",
  };
    return(
        <div style={containerStyle}>
            <h1>College : {college.name}</h1>
            <h2>Website : {college.website}</h2>
            <h2>Type : {college.type}</h2>
            {
                college.student.map(student=>(
                    <UserTemplate data={student} />
                ))
            }
        </div>
    )
}

export default CollegeTemplate;