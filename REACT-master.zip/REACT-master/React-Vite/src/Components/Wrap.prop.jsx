export default function Wrap({children,color="green"}){
    return(
        <div style={{color:color,height:"auto" , border:"2px solid red"}}>
            {children}
        </div>
    )
}