// old way to use forwardRef before react 19 version

// import { forwardRef } from "react";
// const Country=(props,ref)=>{
//     return(
//         <div>
//             <input type="text" ref={ref} />
//         </div>
//     )
// }

// export default forwardRef(Country);


// React 19 version 

const Country=(props)=>{
    return(
        <div>
            <input type="text" ref={props.ref} />
        </div>
    )
}

export default Country;