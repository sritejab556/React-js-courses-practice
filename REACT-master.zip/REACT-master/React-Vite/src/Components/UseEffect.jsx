import { useState,useEffect } from "react";

function UseEffect(){

    
    let [count,setCount]= useState(0);
    let [count2,setCount2]= useState(0);
    // since function execute every time 
    function fun(){
        console.log("fun in called");
    }
    // useEffect(()=>{
    //     fun();
    //     console.log("first")
    // },)
    // useEffect(()=>{
    //     fun();
    //     console.log("second")
    // },[count])
    
    useEffect(()=>{
        fun();
    },[count,count2])
    
    return(
        <div>
            <button onClick={()=>setCount(count+1)}>first Btn {count}</button>
            <button onClick={()=>setCount2(count2+1)}>second Btn {count2}</button>
        </div>
    )
}

export default UseEffect;