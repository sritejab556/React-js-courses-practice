import { useState,useEffect } from "react";

function DisplayClock({color}){
    const [time,setTime] = useState(0);
    useEffect(()=>{
        setInterval(()=>{
            setTime(new Date().toLocaleTimeString());
        },1000);
    },[])
    return(
        <div style={{color:color}}>
            <h1>{time}</h1>
        </div>
    )
}

export default DisplayClock;