function Comp1({fun}){
    const name="manoj";

    return(
        <div>
            <button onClick={()=>{fun(name)}}>{name}</button>
        </div>
    )
}

export default Comp1;