export default function Details2({data="No Data Found"}){
    console.log(data);
    return(
        <div>
            <h2>{data}</h2>
            {/* <h2>Name :{data.name}</h2>
            <h2>Study :{data.study}</h2>
            <h2>Age :{data.age}</h2> */}
        </div>
    )
}