function Comp2({fun}){
    const name="Teja";

    return(
        <div>
            <button onClick={()=>{fun(name)}}>{name}</button>
        </div>
    )
}

export default Comp2;