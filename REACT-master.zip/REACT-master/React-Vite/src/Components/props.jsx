export default function Details({data}){
    console.log(data);
    return(
        <div>
            <h2>Name :{data.nam}</h2>
            <h2>Study :{data.study}</h2>
            <h2>Age :{data.age}</h2>
        </div>
    )
}