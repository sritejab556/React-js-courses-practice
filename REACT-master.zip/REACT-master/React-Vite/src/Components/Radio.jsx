import { useState } from "react";

function Radio_Btn(){

    // const [gender,setGender] = useState('');
    const [gender,setGender] = useState('male');  //this is for by default value we use checked={} in input

    return(
        <div>
            <input onChange={(event)=>setGender(event.target.value)} type="radio" name="gender" id="male" value="male" checked={gender==="male"} />
            <label htmlFor="male">Male</label>
            <input onChange={(event)=>setGender(event.target.value)} type="radio" name="gender" id="female" value="female" checked={gender==="female"}/>
            <label htmlFor="female">Female</label>
            <input onChange={(event)=>setGender(event.target.value)} type="radio" name="gender" id="other" value="other" checked={gender==="other"}/>
            <label htmlFor="other">Other</label>
            <h2>Selected Gender : {gender}</h2>
        </div>
    )
}

export default Radio_Btn;