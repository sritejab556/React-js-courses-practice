import { useState } from "react"
import DisplayClock from "./Clock"

function ColorSelect(){
    const [color,setColor]=useState("red")
    return(
        <div>
            <select onChange={(event)=>{setColor(event.target.value)}}>
                <option value="red">Red</option>
                <option value="blue">Blue</option>
                <option value="green">Green</option>
            </select>
            <DisplayClock color={color}/>
        </div>
    )
}

export default ColorSelect;