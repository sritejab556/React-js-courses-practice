// import { Button } from "bootstrap";
// or 
import Button from "react-bootstrap/Button"
import { Alert } from "react-bootstrap"
function Boot(){
    return(
        <div>
            <button>Click</button>
            <Button >Click</Button>
            <Button variant="primary">Click</Button>
            <Button variant="secondary">Click</Button>
            <Button variant="danger">Click</Button>
            <Button variant="warning">Click</Button>

            <Alert variant="danger" >this is alert</Alert>
            <Alert variant="info" >this is alert</Alert>
            <Alert variant="success" >this is alert</Alert>

        </div>
    )
}

export default Boot;