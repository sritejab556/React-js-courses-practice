import Comp1 from "./Comp1";
import Comp2 from "./Comp2";
function Fun1(){
    const fun=(name)=>{
        alert(`hi ${name}`)
    }
    return(
        <div>
            <Comp1 fun={fun} />
            <br />
            <Comp2 fun={fun} />
        </div>
    )
}

export default Fun1;