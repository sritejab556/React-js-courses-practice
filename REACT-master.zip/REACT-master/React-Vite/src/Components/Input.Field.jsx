import { useState } from "react"

export default function StuForm(){
    let [stu_name,setName] = useState("");
    let [stu_Roll,setRoll] = useState("");
    let [stu_Branch,setBranch] = useState("");
    return(
        <div>
            <input type="text" onChange={(event)=>setName(event.target.value)} value={stu_name} placeholder="Enter your name"/>
            <h1>{stu_name}</h1><br />
            <button onClick={()=>{setName("")}}>Clear</button><br />
            
            <input type="number" onChange={(event)=>setRoll(event.target.value)} value={stu_Roll} placeholder="Enter your Roll number"/>
            <h1>{stu_Roll}</h1><br />
            <button onClick={()=>{setRoll("")}}>Clear</button><br />
            
            <input type="text" onChange={(event)=>setBranch(event.target.value)} value={stu_Branch} placeholder="Enter your Branch"/>
            <h1>{stu_Branch}</h1><br />
            <button onClick={()=>{setBranch("")}}>Clear</button><br />
        </div>

        // in order to use only one button we can use form 
        /*
        <div>
        <form method="get" onSubmit={function}>
            <input type="text" onChange={(event)=>setName(event.target.value)} value={stu_name} placeholder="Enter your name"/>
            <h1>{stu_name}</h1><br />
            
            <input type="number" onChange={(event)=>setRoll(event.target.value)} value={stu_Roll} placeholder="Enter your Roll number"/>
            <h1>{stu_Roll}</h1><br />
            
            <input type="text" onChange={(event)=>setBranch(event.target.value)} value={stu_Branch} placeholder="Enter your Branch"/>
            <h1>{stu_Branch}</h1><br />
            <button onClick={()=>{setBranch("");setRoll("");setName("");}}>Clear</button><br />
            <button type="sumbit">Submit</button>
        </form>
        </div>
        */

    )
}