import { useState } from "react";

function Multiple_condition(){
    const [count,Setcount]=useState(0);
    return(
        <div>
            <h1>{count}</h1>
            <button onClick={()=>{Setcount(count+1)}}>Plus 1</button>
            {
            count==0?<h2>Count is 0</h2>
            :count==1?<h2>Count is 1</h2>
            :count==2?<h2>Count is 2</h2>
            :count==3?<h2>Count is 3</h2>
            :count==4?<h2>Count is 4</h2>
            :count==5?<h2>Count is 5</h2>
            :<h2>Count is more than 5</h2>
            }
        </div>
    )
}

export default Multiple_condition;