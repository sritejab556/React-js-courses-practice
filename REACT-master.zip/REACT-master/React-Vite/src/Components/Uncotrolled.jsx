import { useRef } from "react";

function Uncontrolled(){

    const nameRef=useRef();
    const passwordRef=useRef();

    const HandleInput=(event)=>{
        event.preventDefault();

        const name=document.querySelector('#name').value;
        const pass=document.querySelector("#password").value;
        console.log(name,pass)
    }

    const HandleInputRef=(event)=>{
        event.preventDefault();
        console.log(nameRef.current.value);
        console.log(passwordRef.current.value);
        
    }
    return(
        <div>
            <h1>Uncontrolled Component</h1>
            <form action="" method="post" onSubmit={HandleInput}>
                
            <input type="text" id="name" /><br />
            <input type="password" id="password" /><br />
            <br />
            <button>Submit</button>
            </form>

            <hr />
            <h1>Uncontrolled Component with UseRef</h1>
            <form action="" method="post" onSubmit={HandleInputRef}>
                
            <input type="text" ref={nameRef}/><br />
            <input type="password" ref={passwordRef}/><br />
            <br />
            <button>Submit</button>
            </form>

        </div>
    )
}

export default Uncontrolled;