function DisplayUserData(){
    const userData=[
        {
            name:"teja",
            dept:"IT",
            cgpa:4.3,
            id:"22331A1243"
        },
        {
            name:"vamsi",
            dept:"IT",
            cgpa:7.3,
            id:"22331A1244"
        },
        {
            name:"vignesh",
            dept:"IT",
            cgpa:8.3,
            id:"22331A1245"
        },
        {
            name:"janaki",
            dept:"IT",
            cgpa:9.3,
            id:"22331A1241"
        },
    ]

    return(
        <div>
            <h2>Basic Structure of table</h2>
            <table border={"1.0"}>
                <thead>
                    <tr>
                        <td>id</td>
                        <td>name</td>
                        <td>dept</td>
                        <td>cgpa</td>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>22331a1243</td>
                        <td>teja</td>
                        <td>IT</td>
                        <td>4.3</td>
                    </tr>
                    <tr>
                        <td>22331a1244</td>
                        <td>vamsi</td>
                        <td>IT</td>
                        <td>7.3</td>
                    </tr>
                    <tr>
                        <td>22331a1245</td>
                        <td>vignesh</td>
                        <td>IT</td>
                        <td>8.3</td>
                    </tr>
                    <tr>
                        <td>22331a1241</td>
                        <td>janaki</td>
                        <td>IT</td>
                        <td>9.3</td>
                    </tr>
                </tbody>
            </table>

            {/* looping the array of objects and inserting data into the table */}
            <h2>using loops</h2>
            <table border={1.0}>
                <thead>
                    <tr>
                        <td>id</td>
                        <td>name</td>
                        <td>dept</td>
                        <td>cgp</td>
                    </tr>
                </thead>
                <tbody>
                    {
                        userData.map((user)=>(
                            <tr key={user.id}>
                                <td>{user.id}</td>
                                <td>{user.name}</td>
                                <td>{user.dept}</td>
                        <td>{user.cgpa}</td>
                    </tr>
                    ))
                }
                </tbody>
            </table>
        </div>
    )
}


export default DisplayUserData;