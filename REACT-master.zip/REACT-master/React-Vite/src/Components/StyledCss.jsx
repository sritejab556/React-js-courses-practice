import styled from "styled-components";

function StyledCss(){
    // way 1 
    const Heading=styled.h1`
    color:red;
    background-color:green;
    `

    // way 2

    const Heading1=styled.h1({
        color:'red',
        backgroundColor:'green',
    })
    return(
        <div>
            <Heading>This is heading </Heading>
            <Heading1>This is heading 1 </Heading1>

        </div>
    )
}

export default StyledCss;