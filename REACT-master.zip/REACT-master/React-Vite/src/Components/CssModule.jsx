import style from "../Styles/CssModule.module.css";

function CheckStyle(){
    return(
        <div className={style.container}>
        <h1 className={style.heading}>Teja</h1>
        </div>
    )
}
export default CheckStyle;
