// jsx with curly braces
function Dog(){
    const img="https://images.pexels.com/photos/1108099/pexels-photo-1108099.jpeg?auto=compress&cs=tinysrgb&w=600";
    return (
        <div>
            <img src={img} alt="image" />
                  <h1>{name?name:"name not found"}</h1>
        </div>
    )
}

export default Dog;