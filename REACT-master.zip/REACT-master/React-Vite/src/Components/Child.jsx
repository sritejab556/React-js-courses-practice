export default function Child({func}){
    return(
        <div>
            <button onClick={()=>{func(val=>val+1)}}>Increment</button>        
        </div>
    )
}