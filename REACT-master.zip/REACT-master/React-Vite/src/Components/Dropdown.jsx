import { useState } from "react";

function Dropdown(){
    const [country,setCountry]=useState("");
    return(
        <div>
            <select defaultValue={"India"} onChange={(event)=>setCountry(event.target.value)}>
                <option value="india">India</option>
                <option value="germany">Germany</option>
                <option value="england">England</option>
                <option value="srilanka">Sri lanka</option>
                <option value="usa">USA</option>
                <option value="africa">Africa</option>
            </select>
            <h2>Selected Country : {country}</h2>
        </div>
    )
}

export default Dropdown;