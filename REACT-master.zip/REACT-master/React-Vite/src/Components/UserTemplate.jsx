function UserTemplate({ data }) {
  const containerStyle = {
    border: "1px solid #ddd",
    padding: "16px",
    borderRadius: "8px",
    maxWidth: "280px",
    margin: "16px auto",
  };

  return (
    <div style={containerStyle}>
      <h3>Name: {data.name}</h3>
      <h3>Rollno: {data.id}</h3>
      <h3>Dept: {data.dept}</h3>
      <h3>CGPA: {data.cgpa}</h3>
    </div>
  );
}

export default UserTemplate;
