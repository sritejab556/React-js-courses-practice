import {useRef} from "react";
import Country from "./ForwardRef";
function UseRef(){
    const valRef=useRef(null);
    function onFocus() {
        valRef.current.focus();
        valRef.current.style.color="red";
        valRef.current.placeholder="button clicked ";
        valRef.current.value="Teja";
    }

    function HandleToggle(){
        if(valRef.current.style.display!='none'){
            valRef.current.style.display='none';
        }else{
            valRef.current.style.display='inline';
        }
    }

    const countryName=useRef();

    const HandleCountry=()=>{
        countryName.current.focus();
        countryName.current.value="india";
    }
    return(
        <div>
            <button onClick={HandleToggle}>Toggle</button>
            <input ref={valRef} type="text" placeholder="Enter text"  />
            <button onClick={onFocus}>Focus</button>
            <br />
            <h1>forwardref</h1>
            <br />
            {/* <input type="text" ref={countryName}/> */}
            <Country ref={countryName}/>
            <button onClick={HandleCountry}>Click to focus</button>
        </div>
    )
}

export default UseRef;