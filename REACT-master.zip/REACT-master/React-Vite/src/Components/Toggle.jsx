import { useState } from "react"

export default function Toggle(){
    const [val,boolVal]=useState(true);
    function toggleVal(){
        boolVal(val=>!val);
    }
    return(
        <div>
            <button onClick={toggleVal}>{val?"True":"False"}</button>
            {val?<h1>It's True</h1>:<h1>It's not True</h1>}
        </div>
    );
}