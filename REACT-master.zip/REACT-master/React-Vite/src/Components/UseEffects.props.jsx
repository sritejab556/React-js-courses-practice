
import { useEffect } from "react"
const Props = ({ count1, count2 }) => {

    function HandleCount1() {
        console.log(`count1 is ${count1}`)
    }
    function HandleCount2() {
        console.log(`count2 is ${count2}`)
        return(()=>{
            console.log("❌ Component will unmount");
        })
    }
    
    useEffect(() => { HandleCount1() }, [count1]);
    useEffect(() => { HandleCount2() }, [count2]);
    return (
        <div>
            <h1>count1 value {count1} </h1>
            <h1>count1 value {count2} </h1>
        </div>
    )
}

export default Props;