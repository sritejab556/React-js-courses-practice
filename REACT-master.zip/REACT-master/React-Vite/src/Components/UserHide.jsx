import {useState} from "react";
import Usergreet from "./User";




function UserHide(){
    const [name,ChangeVal]=useState(true);
    function greet(){
        ChangeVal(val=>!val);
    }

    return(
        <div>
            <button onClick={greet}>Greet | No Greet</button>
            {name?<Usergreet/>:null}
            
        </div>
    )

}

export default UserHide;