import UserTemplate from "./UserTemplate";

function UserData(){
    const users=[
        {
            name:"teja",
            dept:"IT",
            cgpa:4.3,
            id:"22331A1243"
        },
        {
            name:"vamsi",
            dept:"IT",
            cgpa:7.3,
            id:"22331A1244"
        },
        {
            name:"vignesh",
            dept:"IT",
            cgpa:8.3,
            id:"22331A1245"
        },
        {
            name:"janaki",
            dept:"IT",
            cgpa:9.3,
            id:"22331A1241"
        },
    ]
    return(
        <div>
            {
                users.map((user)=>(
                    <div key={user.id}>
                   <UserTemplate data={user} />
                    </div>
                ))
            }
        </div>
    )
}

export default UserData;