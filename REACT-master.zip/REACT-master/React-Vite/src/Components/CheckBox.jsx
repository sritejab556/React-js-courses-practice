import { use, useState } from "react";
function CheckBox(){
    const [skills,setSkills] = useState([]);
    
    const HandleSkills=(event)=>{
        // console.log(event.target.value , event.target.checked);
        let skill=event.target.value;
        if(event.target.checked){
            setSkills([...skills,skill]);
        }
        else{
            setSkills([skills.filter((item)=>item!=skill)])
        }
    }
    return(
        <div>
            <h2>Select your skills</h2>
            <input onChange={HandleSkills}  type="checkbox" id="javascript" value="javascript"/>
            <label htmlFor="javascript">javascript</label>
            <br />

            <input onChange={HandleSkills}  type="checkbox" id="cpp" value="cpp"/>
            <label htmlFor="cpp">cpp</label>
            <br />
            <input onChange={HandleSkills}  type="checkbox" id="node" value="node"/>
            <label htmlFor="node">node</label>
            <br />

            <input onChange={HandleSkills}  type="checkbox" id="react" value="react"/>
            <label htmlFor="react">react</label>
            <br />
            <h1>{skills.join(",")}</h1>
            
        </div>
    )
}

export default CheckBox;