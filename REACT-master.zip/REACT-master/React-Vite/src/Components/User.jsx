function Usergreet(){
    return(
        <div>
            <h1>Hi Im Teja</h1>
            <Usergreet2/>
        </div>
    )
}
function Usergreet2(){
    return(
        <h1>How are you</h1>
    )
}

export default (Usergreet);