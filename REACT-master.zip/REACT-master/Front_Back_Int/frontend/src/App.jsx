import { useState,useEffect } from 'react'
import axios from "axios";
import './App.css'

function App() {
  const [jokes, setJokes] = useState([])

  useEffect(()=>{
    HandleJokes();
  },[])
  
  async function HandleJokes(){
    try{
      const response= await axios.get("/jokes");
      console.log(response);
      let jokeData=await response.data;
      setJokes(jokeData);
    }
    catch(err){
      console.log(`error from HandleJokes() ${err}`);
    }
  }
  return (
    <>
       <h1>Jokes of mine</h1> 
       {
         
         jokes.map((joke)=>(
          <div key={joke.id}>
            <h2>{joke.title}</h2>
            <h3>{joke.content}</h3>
        </div>
        ))

       }
    </>
  )
}

export default App
