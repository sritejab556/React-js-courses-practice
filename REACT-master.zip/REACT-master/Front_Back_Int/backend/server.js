import express from "express";
// import cors from "cors";   //commented this so we can use proxy instead
const app = express();

// app.use(cors()); // Allow all origins — for development only

// app.get("/",(req,res)=>{
//     res.send("hi")
// })
const jokes=[
  {
    id:1,
    title:"joke1",
    content:"this is  joke1"
  },
  {
    id:2,
    title:"joke2",
    content:"this is  joke2"
  },
  {
    id:3,
    title:"joke3",
    content:"this is  joke3"
  },

]

app.get("/jokes",(req,res)=>{
  res.send(jokes);
})
const port = process.env.PORT || 5000;

app.listen(port, () => {
  console.log(`server running on http://localhost:${port}`);
});
