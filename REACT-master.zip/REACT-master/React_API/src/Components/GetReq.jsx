import { useState, useEffect } from 'react'
import { useNavigate } from 'react-router';

function GetReq() {
  const [userData, setUserData] = useState([]);
  const [userPosts, setUserPosts] = useState([]);
  const [loader,setLoader] =useState(false);
  const navigate=useNavigate();

  useEffect(() => {
    setLoader(true)
    getUserPosts();
    getUserData();
  },[])


  async function getUserData() {
    const users = "https://dummyjson.com/users";
    let response = await fetch(users);
    // console.log(response.json());
    let data = await response.json(); // ✅ parse JSON
    setUserData(data.users);          // ✅ now access 'users'
    setLoader(false);
  }
  
  async function getUserPosts(){
    const posts_URL="http://localhost:3000/posts";
    let response=await fetch(posts_URL);
    let posts=  await response.json();
    console.log(posts);
    setUserPosts(posts);
    setLoader(false);
  }

  async function deletePost(id) {
    console.log(id);

    const postdeleteurl="http://localhost:3000/posts";
    let response=await fetch(postdeleteurl+"/"+id,{
        method:'DELETE',
    });
    response =await response.json();
    console.log(response)    
    getUserPosts();

  }

  async function EditPost(id){
    navigate("/edit/"+id);
    

  }




  // console.log(userData);


  return (
    <>
      {/* <h1>Users Data</h1>
      {loader? <h1>Loading..</h1> :
        userData.map((user) => (
          <div key={user.id}>
            <h2>{user.username}</h2>
          </div>
        ))
      } */}

      <h1>User posts</h1>
      {loader?<h1>Loading..</h1>:
        userPosts.map((post)=>(
          <ul key={post.id}>
            <li>{post.title}</li>
            <li>{post.views}</li>
            <button onClick={()=>{deletePost(post.id)}}>Delete</button>
            <button onClick={()=>{EditPost(post.id)}}>Edit</button>
          </ul>
        ))
      }

    </>
  )
}

export default GetReq;
