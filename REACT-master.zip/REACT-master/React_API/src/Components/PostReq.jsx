import { useState} from 'react';
import { useNavigate } from 'react-router';
const PostReq = () => {
    const [title,Settitle]=useState('');
    const [views,Setviews]=useState('');
    const navigate=useNavigate();

    async function HandlePost(){
        const postUrl="http://localhost:3000/posts";

        let response=await fetch(postUrl,
            {
                method:"post",
                body:JSON.stringify({title,views})
            }
        );
        
        response=await response.json();
        console.log(response)
        
        navigate("/");
    }
    return (
    <div>
        <input type="text" placeholder='Enter title' onChange={(event)=>{Settitle(event.target.value)}}/><br />
        <input type="number" placeholder='Enter Views' onChange={(event)=>{Setviews(event.target.value)}}/><br />
        <button onClick={HandlePost}>submit</button><br />
    </div>
  );
};

export default PostReq;