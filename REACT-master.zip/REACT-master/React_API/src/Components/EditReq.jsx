import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router";

const EditReq = () => {
    const {id}=useParams();
    const [title,Settitle]=useState('');
    const [views,Setviews]=useState('');
    const navigate=useNavigate();


useEffect(() => {
  getUserPostData();
}, []);


    async function getUserPostData(){
        const url=`http://localhost:3000/posts/${id}`;
        let response=await fetch(url);
        response=await response.json();
        Settitle(response.title);
        Setviews(response.views);
    }
    
    async function updatepostDate(){
        const url=`http://localhost:3000/posts/${id}`;
        let response=await fetch(url,{
            method:"PUT",
            body:JSON.stringify({title,views})
        });
        response=await response.json();
        if(response){
            Settitle(response.title);
            Setviews(response.views)
        }
        navigate("/");


    }
    return (
        <div>
            <h1>Edit page</h1>
            <input type="text" value={title} placeholder='Enter Title' onChange={(event)=>Settitle(event.target.value)} /><br />
            <input type="number" value={views} placeholder='Enter Views'  onChange={(event)=>Setviews(event.target.value)} /><br />
            <button onClick={updatepostDate}>Update</button><br />
        </div>
    );
};

export default EditReq;