import { NavLink, Route, Routes} from "react-router";
import GetReq from "./Components/GetReq";
import PostReq from "./Components/PostReq";
import EditReq from "./Components/EditReq";

function App() {

  return (
    <div>
      <NavLink to="/">home</NavLink><br />
      <NavLink to="/post">post</NavLink>
    <Routes>
      <Route path="/" element={<GetReq />}/>
      <Route path="/post" element={<PostReq />}/>
      <Route path="/edit/:id" element={<EditReq />}/>

    </Routes>
    </div>
  )
}

export default App
